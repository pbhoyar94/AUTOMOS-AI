#!/bin/bash
# AUTOMOS AI Health Check Script

echo "Performing health check..."

# Check if AUTOMOS AI is running
if pgrep -f "python3 main.py" > /dev/null; then
    echo "AUTOMOS AI process is running"
else
    echo "AUTOMOS AI process is not running"
    exit 1
fi

# Check memory usage
if command -v ps &> /dev/null; then
    MEMORY_USAGE=$(ps aux | grep "python3 main.py" | grep -v grep | awk '{print $4}' | head -1)
    echo "Memory usage: ${MEMORY_USAGE}%"
fi

# Check CPU usage
if command -v ps &> /dev/null; then
    CPU_USAGE=$(ps aux | grep "python3 main.py" | grep -v grep | awk '{print $3}' | head -1)
    echo "CPU usage: ${CPU_USAGE}%"
fi

# Check log files for errors
if [ -f "logs/automos_ai.log" ]; then
    ERROR_COUNT=$(grep -c "ERROR" logs/automos_ai.log 2>/dev/null || echo "0")
    echo "Error count in logs: $ERROR_COUNT"
    
    WARNING_COUNT=$(grep -c "WARNING" logs/automos_ai.log 2>/dev/null || echo "0")
    echo "Warning count in logs: $WARNING_COUNT"
fi

echo "Health check completed"
