#!/bin/bash
# AUTOMOS AI Stop Script

echo "Stopping AUTOMOS AI..."

# Find and kill AUTOMOS AI processes
if pgrep -f "python3 main.py" > /dev/null; then
    pkill -f "python3 main.py"
    echo "AUTOMOS AI processes stopped"
else
    echo "No AUTOMOS AI processes found"
fi

echo "AUTOMOS AI stopped"
