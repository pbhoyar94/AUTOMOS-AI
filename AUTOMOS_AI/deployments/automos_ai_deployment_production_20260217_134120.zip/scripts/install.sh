#!/bin/bash
# AUTOMOS AI Installation Script

set -e

echo "Installing AUTOMOS AI..."

# Check Python version
python3 --version || (echo "Python 3 required" && exit 1)

# Install system dependencies
echo "Installing system dependencies..."
if command -v apt-get &> /dev/null; then
    sudo apt-get update
    sudo apt-get install -y python3-pip python3-venv build-essential cmake
elif command -v yum &> /dev/null; then
    sudo yum update -y
    sudo yum install -y python3-pip python3-venv gcc gcc-c++ make cmake
fi

# Create virtual environment
echo "Creating virtual environment..."
python3 -m venv automos_ai_env
source automos_ai_env/bin/activate

# Install Python dependencies
echo "Installing Python dependencies..."
pip install --upgrade pip
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
pip install opencv-python numpy scipy
pip install psutil pyyaml
pip install -r requirements.txt

# Set permissions
chmod +x scripts/start_automos_ai.sh
chmod +x scripts/stop_automos_ai.sh
chmod +x scripts/health_check.sh

echo "Installation completed successfully!"
echo "Run 'source automos_ai_env/bin/activate' to activate the environment"
echo "Run 'scripts/start_automos_ai.sh' to start AUTOMOS AI"
