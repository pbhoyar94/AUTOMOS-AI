#!/bin/bash
# AUTOMOS AI Start Script

set -e

echo "Starting AUTOMOS AI..."

# Activate virtual environment
if [ -d "automos_ai_env" ]; then
    source automos_ai_env/bin/activate
fi

# Detect device type
DEVICE_TYPE="industrial_pc"
if [ -f /proc/device-tree/model ]; then
    MODEL=$(cat /proc/device-tree/model)
    if [[ $MODEL == *"Jetson Nano"* ]]; then
        DEVICE_TYPE="jetson_nano"
    elif [[ $MODEL == *"Jetson Xavier"* ]]; then
        DEVICE_TYPE="jetson_xavier"
    fi
fi

if [ -f /proc/cpuinfo ]; then
    if grep -q "ARMv7" /proc/cpuinfo; then
        DEVICE_TYPE="raspberry_pi_4"
    fi
fi

echo "Detected device type: $DEVICE_TYPE"

# Create logs directory
mkdir -p logs

# Start AUTOMOS AI
echo "Starting AUTOMOS AI with $DEVICE_TYPE configuration..."
python3 main.py --mode deployment --hardware edge 2>&1 | tee logs/automos_ai.log

echo "AUTOMOS AI started"
